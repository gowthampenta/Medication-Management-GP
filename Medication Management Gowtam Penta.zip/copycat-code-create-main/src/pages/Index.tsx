
import { useState } from "react";
import RoleSelection from "@/components/RoleSelection";
import PatientDashboard from "@/components/PatientDashboard";
import CaretakerDashboard from "@/components/CaretakerDashboard";

export type UserRole = "patient" | "caretaker" | null;

const Index = () => {
  const [userRole, setUserRole] = useState<UserRole>(null);

  const handleRoleSelect = (role: UserRole) => {
    setUserRole(role);
  };

  const switchRole = () => {
    setUserRole(userRole === "patient" ? "caretaker" : "patient");
  };

  if (!userRole) {
    return <RoleSelection onRoleSelect={handleRoleSelect} />;
  }

  return userRole === "patient" ? (
    <PatientDashboard onSwitchRole={switchRole} />
  ) : (
    <CaretakerDashboard onSwitchRole={switchRole} />
  );
};

export default Index;
