
import { useState } from "react";
import { Heart, User, Camera, Check, Calendar, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface PatientDashboardProps {
  onSwitchRole: () => void;
}

const PatientDashboard = ({ onSwitchRole }: PatientDashboardProps) => {
  const [currentDate] = useState(new Date());
  const [medicationTaken, setMedicationTaken] = useState(false);

  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const firstDayOfWeek = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }
    
    return days;
  };

  const days = generateCalendarDays();
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-teal-500 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold">M</span>
            </div>
            <div>
              <h1 className="font-semibold text-gray-900">MediCare Companion</h1>
              <p className="text-sm text-gray-500">Patient View</p>
            </div>
          </div>
          <Button variant="outline" onClick={onSwitchRole} className="text-sm">
            <User className="w-4 h-4 mr-2" />
            Switch to Caretaker
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Welcome Banner */}
        <div className="bg-gradient-to-r from-blue-500 to-teal-500 rounded-2xl p-8 mb-8 text-white">
          <div className="flex items-center mb-4">
            <User className="w-8 h-8 mr-3" />
            <div>
              <h2 className="text-2xl font-bold">Good Morning!</h2>
              <p className="text-blue-100">Ready to stay on track with your medication?</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-3xl font-bold">0</div>
              <div className="text-sm text-blue-100">Day Streak</div>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-3xl font-bold">○</div>
              <div className="text-sm text-blue-100">Today's Status</div>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-3xl font-bold">0%</div>
              <div className="text-sm text-blue-100">Monthly Rate</div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Today's Medication */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-blue-600" />
                  Today's Medication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-semibold text-sm">1</span>
                    </div>
                    <div>
                      <h3 className="font-medium">Daily Medication Set</h3>
                      <p className="text-sm text-gray-500">Complete set of daily tablets</p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500">8:00 AM</div>
                </div>

                {/* Photo Upload Section */}
                <div className="border-2 border-dashed border-gray-200 rounded-lg p-8 text-center">
                  <Camera className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="font-medium text-gray-900 mb-2">Add Proof Photo (Optional)</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Take a photo of your medication or pill organizer as confirmation
                  </p>
                  <Button variant="outline" className="mb-4">
                    <Camera className="w-4 h-4 mr-2" />
                    Take Photo
                  </Button>
                </div>

                {/* Mark as Taken Button */}
                <Button 
                  className={`w-full h-12 ${medicationTaken ? 'bg-green-600 hover:bg-green-700' : 'bg-green-600 hover:bg-green-700'}`}
                  onClick={() => setMedicationTaken(!medicationTaken)}
                >
                  <Check className="w-5 h-5 mr-2" />
                  {medicationTaken ? 'Marked as Taken' : 'Mark as Taken'}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Medication Calendar */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Medication Calendar</CardTitle>
                <div className="flex items-center justify-between">
                  <Button variant="ghost" size="sm">
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="font-medium">
                    {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
                  </span>
                  <Button variant="ghost" size="sm">
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(day => (
                    <div key={day} className="text-center text-xs font-medium text-gray-500 p-2">
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {days.map((day, index) => (
                    <div key={index} className="aspect-square">
                      {day && (
                        <div className={`
                          w-full h-full flex items-center justify-center text-sm rounded-lg cursor-pointer
                          ${day === 19 ? 'bg-blue-600 text-white' : 
                            [8, 9, 10, 11, 12, 15, 16, 17, 18].includes(day) ? 'bg-green-100 text-green-800' :
                            [1, 2, 7, 14].includes(day) ? 'bg-red-100 text-red-800' :
                            'hover:bg-gray-100'}
                        `}>
                          {day}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                    <span>Medication taken</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                    <span>Missed medication</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                    <span>Today</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;
