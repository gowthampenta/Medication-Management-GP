
import { Users, User, Bell, Mail, Calendar, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface CaretakerDashboardProps {
  onSwitchRole: () => void;
}

const CaretakerDashboard = ({ onSwitchRole }: CaretakerDashboardProps) => {
  const tabs = [
    { id: 'overview', label: 'Overview', active: true },
    { id: 'activity', label: 'Recent Activity', active: false },
    { id: 'calendar', label: 'Calendar View', active: false },
    { id: 'notifications', label: 'Notifications', active: false },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-teal-500 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold">M</span>
            </div>
            <div>
              <h1 className="font-semibold text-gray-900">MediCare Companion</h1>
              <p className="text-sm text-gray-500">Caretaker View</p>
            </div>
          </div>
          <Button variant="outline" onClick={onSwitchRole} className="text-sm">
            <User className="w-4 h-4 mr-2" />
            Switch to Patient
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Welcome Banner */}
        <div className="bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl p-8 mb-8 text-white">
          <div className="flex items-center mb-4">
            <Users className="w-8 h-8 mr-3" />
            <div>
              <h2 className="text-2xl font-bold">Caretaker Dashboard</h2>
              <p className="text-green-100">Monitoring Eleanor Thompson's medication adherence</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-6">
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-3xl font-bold">85%</div>
              <div className="text-sm text-green-100">Adherence Rate</div>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-3xl font-bold">5</div>
              <div className="text-sm text-green-100">Current Streak</div>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-3xl font-bold">3</div>
              <div className="text-sm text-green-100">Missed This Month</div>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-3xl font-bold">4</div>
              <div className="text-sm text-green-100">Taken This Week</div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                tab.active 
                  ? 'bg-white text-gray-900 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Today's Status */}
          <div className="lg:col-span-2">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-blue-600" />
                  Today's Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h3 className="font-medium">Daily Medication Set</h3>
                    <p className="text-sm text-gray-500">8:00 AM</p>
                  </div>
                  <span className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">
                    Pending
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Monthly Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-green-600" />
                  Monthly Adherence Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>Overall Progress</span>
                    <span>85%</span>
                  </div>
                  <Progress value={85} className="h-3" />
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-center text-sm">
                  <div>
                    <div className="text-green-600 font-semibold">22 days</div>
                    <div className="text-gray-500">Taken</div>
                  </div>
                  <div>
                    <div className="text-red-600 font-semibold">3 days</div>
                    <div className="text-gray-500">Missed</div>
                  </div>
                  <div>
                    <div className="text-blue-600 font-semibold">5 days</div>
                    <div className="text-gray-500">Remaining</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full justify-start">
                  <Mail className="w-4 h-4 mr-3" />
                  Send Reminder Email
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Bell className="w-4 h-4 mr-3" />
                  Configure Notifications
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="w-4 h-4 mr-3" />
                  View Full Calendar
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CaretakerDashboard;
